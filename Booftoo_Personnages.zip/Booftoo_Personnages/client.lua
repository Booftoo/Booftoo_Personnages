local characters = {}

-- Commande pour afficher la liste des personnages
RegisterCommand('personnages', function()
    TriggerServerEvent('booftoo_perso:getCharacters')
end, false)

-- Affiche la liste des personnages dans le menu RageUI
RegisterNetEvent('booftoo_perso:showCharacters', function(data)
    characters = data
    openCharacterMenu()
end)

-- Affichage des données du personnage et actions associées
RegisterNetEvent('booftoo_perso:displayPlayerData', function(playerData)
    if playerData then
        -- Notification des informations du personnage (Visible par tous les joueurs)
        ESX.ShowNotification(('Chargé: %s %s\nMétier: %s\nPosition: x: %.2f, y: %.2f, z: %.2f'):format(
            playerData.firstname,
            playerData.lastname,
            playerData.job.name,
            playerData.position.x,
            playerData.position.y,
            playerData.position.z
        ))

        -- Téléportation à la position
        local ped = PlayerPedId()
        SetEntityCoords(ped, playerData.position.x, playerData.position.y, playerData.position.z)
        SetEntityHeading(ped, playerData.position.heading)

        -- Chargement du skin
        if playerData.skin and next(playerData.skin) ~= nil then
            TriggerEvent('skinchanger:loadSkin', playerData.skin)
        else
            ESX.ShowNotification('Aucun skin trouvé pour ce personnage.')
        end

        -- Chargement des comptes (argent)
        if playerData.accounts then
            for account, amount in pairs(playerData.accounts) do
                TriggerEvent('esx:setAccountMoney', account, amount)
            end
        end

        ESX.ShowNotification('Personnage chargé avec succès. Vous avez accès à son inventaire.')
    else
        ESX.ShowNotification('Personnage introuvable.')
    end
end)

-- Menu RageUI pour afficher et charger un personnage
function openCharacterMenu()
    local mainMenu = RageUI.CreateMenu('Personnages', 'Liste des joueurs déconnectés')
    local inputId = nil

    RageUI.Visible(mainMenu, not RageUI.Visible(mainMenu))

    while mainMenu do
        Citizen.Wait(0)
        RageUI.IsVisible(mainMenu, function()
            for _, char in ipairs(characters) do
                RageUI.Button(string.format('ID: %d - %s %s', char.id, char.firstname, char.lastname), nil, { RightLabel = '→' }, true, {
                    onSelected = function()
                        TriggerServerEvent('booftoo_perso:loadPlayerData', char.id)
                    end
                })
            end

            RageUI.Button('Charger un personnage par ID', 'Entrez l\'ID du personnage à charger.', {}, true, {
                onSelected = function()
                    inputId = KeyboardInput('ID du personnage', '', 10)
                    if inputId and tonumber(inputId) then
                        TriggerServerEvent('booftoo_perso:loadPlayerData', tonumber(inputId))
                    else
                        ESX.ShowNotification('Veuillez entrer un ID valide.')
                    end
                end
            })
        end)

        if not RageUI.Visible(mainMenu) then
            mainMenu = RMenu:DeleteType("mainMenu", true)
            break
        end
    end
end

-- Fonction pour saisir l'ID via le clavier
function KeyboardInput(textEntry, placeholder, maxLength)
    AddTextEntry('FMMC_KEY_TIP1', textEntry)
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", placeholder, "", "", "", maxLength)

    while UpdateOnscreenKeyboard() == 0 do
        Citizen.Wait(0)
    end

    if GetOnscreenKeyboardResult() then
        return GetOnscreenKeyboardResult()
    end

    return nil
end
