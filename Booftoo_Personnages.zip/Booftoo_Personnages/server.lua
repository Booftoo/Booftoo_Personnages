local ESX = exports["es_extended"]:getSharedObject()

-- Vérifie si le joueur est admin et renvoie les personnages déconnectés
RegisterNetEvent('booftoo_perso:getCharacters', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    if xPlayer and xPlayer.getGroup() == 'admin' then
        MySQL.query('SELECT * FROM users WHERE id IS NOT NULL', {}, function(result)
            if result and #result > 0 then
                local characters = {}
                for _, user in ipairs(result) do
                    table.insert(characters, {
                        id = user.id,
                        firstname = user.firstname or "N/A",
                        lastname = user.lastname or "N/A"
                    })
                end
                TriggerClientEvent('booftoo_perso:showCharacters', _source, characters)
            else
                TriggerClientEvent('esx:showNotification', _source, 'Aucun joueur déconnecté trouvé.')
            end
        end)
    else
        TriggerClientEvent('esx:showNotification', _source, 'Vous n\'avez pas les permissions nécessaires.')
    end
end)


-- Charge un personnage spécifique par son ID
RegisterNetEvent('booftoo_perso:loadPlayerData', function(playerId)
    local _source = source
    MySQL.query('SELECT * FROM users WHERE id = @id', {
        ['@id'] = playerId
    }, function(result)
        if result and result[1] then
            local userData = result[1]
            local playerData = {
                id = userData.id,
                firstname = userData.firstname or "N/A",
                lastname = userData.lastname or "N/A",
                job = { name = userData.job or "unemployed", grade = userData.job_grade or 0 },
                position = json.decode(userData.position) or { x = 0.0, y = 0.0, z = 0.0 },
                skin = json.decode(userData.skin) or {}
            }
            TriggerClientEvent('booftoo_perso:displayPlayerData', _source, playerData)
        else
            TriggerClientEvent('esx:showNotification', _source, 'Personnage introuvable.')
        end
    end)
end)


